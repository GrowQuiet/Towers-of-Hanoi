#include <iostream>
#include <stack>
#include <windows.h>
#include <cstdlib>
#include <unistd.h>
#include <ctime>    // For time()
#include <cstdlib>  // For srand() and rand()
#include "Towers.h"
#include "login.h"

using namespace std;

int main() {
	login test;
	test.print_menu();
	return 0;
}



